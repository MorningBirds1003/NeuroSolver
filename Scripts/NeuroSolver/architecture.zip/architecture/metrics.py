"""
metrics.py

Bundle-level architecture metrics for NeuroSolver sweep analysis.

These helpers extract higher-level propagation and recruitment-style quantities
from per-fiber cable results, such as:
- peak Vm per fiber
- threshold crossing times
- latency spread
- recruited fiber count
- conduction velocity estimates
- a simple CNAP-like amplitude proxy from VC traces
"""

from __future__ import annotations

from typing import Any, Dict, Iterable, Optional

import numpy as np


def _as_float_array(x: Any) -> np.ndarray:
    return np.asarray(x, dtype=float)


def compute_peak_vm_by_fiber(
    per_fiber_cable_results: Dict[int, Dict[str, Any]],
    field_key: str = "V_m_mV",
) -> Dict[int, float]:
    """
    Return peak field value by fiber ID.
    """
    peaks: Dict[int, float] = {}
    for fid, cable in per_fiber_cable_results.items():
        if field_key not in cable:
            continue
        arr = _as_float_array(cable[field_key])
        if arr.size == 0:
            continue
        peaks[int(fid)] = float(np.max(arr))
    return peaks


def compute_threshold_crossing_time_ms_for_trace(
    t_ms: np.ndarray,
    trace: np.ndarray,
    threshold_mV: float = 0.0,
) -> float:
    """
    Return the first time a 1D trace crosses threshold, else np.nan.
    """
    idx = np.where(trace >= float(threshold_mV))[0]
    if idx.size == 0:
        return float(np.nan)
    return float(t_ms[int(idx[0])])


def compute_first_threshold_crossing_by_fiber(
    per_fiber_cable_results: Dict[int, Dict[str, Any]],
    threshold_mV: float = 0.0,
    probe_mode: str = "max_over_compartments",
) -> Dict[int, float]:
    """
    Compute one first-threshold-crossing time per fiber.

    Parameters
    ----------
    probe_mode:
        "max_over_compartments"
            Threshold is checked on the max Vm over compartments at each time.
        "last_compartment"
            Threshold is checked only at the distal compartment.
        "center_compartment"
            Threshold is checked at the center compartment.
    """
    crossings: Dict[int, float] = {}

    for fid, cable in per_fiber_cable_results.items():
        if "t_ms" not in cable or "V_m_mV" not in cable:
            continue

        t_ms = _as_float_array(cable["t_ms"])
        V = _as_float_array(cable["V_m_mV"])  # shape: time x compartment

        if V.ndim != 2 or V.shape[0] == 0 or V.shape[1] == 0:
            crossings[int(fid)] = float(np.nan)
            continue

        if probe_mode == "max_over_compartments":
            probe = np.max(V, axis=1)
        elif probe_mode == "last_compartment":
            probe = V[:, -1]
        elif probe_mode == "center_compartment":
            probe = V[:, V.shape[1] // 2]
        else:
            raise ValueError(f"Unsupported probe_mode: {probe_mode!r}")

        crossings[int(fid)] = compute_threshold_crossing_time_ms_for_trace(
            t_ms=t_ms,
            trace=probe,
            threshold_mV=threshold_mV,
        )

    return crossings


def compute_recruited_fiber_count(
    crossing_times_ms: Dict[int, float],
) -> int:
    """
    Count fibers with a valid threshold crossing.
    """
    count = 0
    for value in crossing_times_ms.values():
        if np.isfinite(value):
            count += 1
    return int(count)


def compute_latency_stats_ms(
    crossing_times_ms: Dict[int, float],
) -> Dict[str, float]:
    """
    Compute latency summary statistics across recruited fibers.
    """
    vals = np.asarray(
        [float(v) for v in crossing_times_ms.values() if np.isfinite(v)],
        dtype=float,
    )

    if vals.size == 0:
        return {
            "latency_min_ms": float(np.nan),
            "latency_max_ms": float(np.nan),
            "latency_mean_ms": float(np.nan),
            "latency_std_ms": float(np.nan),
            "latency_spread_ms": float(np.nan),
        }

    return {
        "latency_min_ms": float(np.min(vals)),
        "latency_max_ms": float(np.max(vals)),
        "latency_mean_ms": float(np.mean(vals)),
        "latency_std_ms": float(np.std(vals)),
        "latency_spread_ms": float(np.max(vals) - np.min(vals)),
    }


def compute_conduction_velocity_m_per_s_for_fiber(
    cable_result: Dict[str, Any],
    threshold_mV: float = 0.0,
) -> float:
    """
    Estimate conduction velocity from first and last compartment threshold times.

    Uses:
        velocity = distance / delta_t

    Returns np.nan if the estimate cannot be formed.
    """
    if "t_ms" not in cable_result or "V_m_mV" not in cable_result:
        return float(np.nan)

    t_ms = _as_float_array(cable_result["t_ms"])
    V = _as_float_array(cable_result["V_m_mV"])

    if V.ndim != 2 or V.shape[1] < 2:
        return float(np.nan)

    if "x_um" in cable_result:
        x_um = _as_float_array(cable_result["x_um"])
    else:
        return float(np.nan)

    if x_um.size != V.shape[1]:
        return float(np.nan)

    t0 = compute_threshold_crossing_time_ms_for_trace(t_ms, V[:, 0], threshold_mV)
    t1 = compute_threshold_crossing_time_ms_for_trace(t_ms, V[:, -1], threshold_mV)

    if not (np.isfinite(t0) and np.isfinite(t1)):
        return float(np.nan)

    dt_ms = float(t1 - t0)
    if dt_ms <= 0.0:
        return float(np.nan)

    dx_m = float((x_um[-1] - x_um[0]) * 1.0e-6)
    dt_s = dt_ms * 1.0e-3
    return float(dx_m / dt_s)


def compute_conduction_velocity_stats_m_per_s(
    per_fiber_cable_results: Dict[int, Dict[str, Any]],
    threshold_mV: float = 0.0,
) -> Dict[str, float]:
    """
    Compute conduction velocity summary stats across fibers.
    """
    values = []
    for cable in per_fiber_cable_results.values():
        v = compute_conduction_velocity_m_per_s_for_fiber(
            cable_result=cable,
            threshold_mV=threshold_mV,
        )
        if np.isfinite(v):
            values.append(float(v))

    arr = np.asarray(values, dtype=float)
    if arr.size == 0:
        return {
            "cv_mean_m_per_s": float(np.nan),
            "cv_std_m_per_s": float(np.nan),
            "cv_min_m_per_s": float(np.nan),
            "cv_max_m_per_s": float(np.nan),
        }

    return {
        "cv_mean_m_per_s": float(np.mean(arr)),
        "cv_std_m_per_s": float(np.std(arr)),
        "cv_min_m_per_s": float(np.min(arr)),
        "cv_max_m_per_s": float(np.max(arr)),
    }


def compute_cnap_like_amplitude_mV(
    vc_result: Optional[Dict[str, Any]],
) -> float:
    """
    Simple CNAP-like proxy from VC traces.

    Current proxy:
        maximum peak-to-peak amplitude among available electrode traces.
    """
    if vc_result is None:
        return float(np.nan)

    ptps = []
    for key, value in vc_result.items():
        if key == "t_ms":
            continue
        arr = _as_float_array(value)
        if arr.size == 0:
            continue
        ptps.append(float(np.ptp(arr)))

    if len(ptps) == 0:
        return float(np.nan)

    return float(np.max(np.asarray(ptps, dtype=float)))


def compute_bundle_metrics(
    result,
    threshold_mV: float = 0.0,
) -> Dict[str, float]:
    """
    Extract bundle-level metrics from an ArchitectureSimulationResult-like object.
    """
    per_fiber = result.per_fiber_cable_results

    crossing_times = compute_first_threshold_crossing_by_fiber(
        per_fiber_cable_results=per_fiber,
        threshold_mV=threshold_mV,
        probe_mode="max_over_compartments",
    )

    recruited_count = compute_recruited_fiber_count(crossing_times)
    latency_stats = compute_latency_stats_ms(crossing_times)
    cv_stats = compute_conduction_velocity_stats_m_per_s(
        per_fiber_cable_results=per_fiber,
        threshold_mV=threshold_mV,
    )
    cnap_like = compute_cnap_like_amplitude_mV(result.vc_result)

    metrics: Dict[str, float] = {
        "recruited_fiber_count": float(recruited_count),
        "recruited_fraction": (
            float(recruited_count) / max(float(len(per_fiber)), 1.0)
            if len(per_fiber) > 0 else float(np.nan)
        ),
        "cnap_like_amplitude_mV": float(cnap_like),
    }

    metrics.update(latency_stats)
    metrics.update(cv_stats)
    return metrics