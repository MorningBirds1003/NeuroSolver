"""
architecture_runner.py

Top-level runner for custom nerve-architecture simulations in NeuroSolver.
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import Any, Dict, Optional, Sequence

import numpy as np

from Scripts.NeuroSolver.params import DEFAULT_PARAMS, SimulationParameters
from Scripts.NeuroSolver.bundle_state import BundleRuntimeState, initialize_bundle_state
from Scripts.NeuroSolver.scheduler import run_multirate_bundle_simulation

from Scripts.NeuroSolver.architecture.architecture_builder import build_bundle_from_architecture
from Scripts.NeuroSolver.architecture.architecture_schema import NerveArchitectureSpec
from Scripts.NeuroSolver.architecture.electrode_geometry import (
    build_electrode_points_from_architecture,
)


@dataclass
class ArchitectureSimulationResult:
    architecture_spec: NerveArchitectureSpec
    bundle_geometry: Any
    bundle_state: BundleRuntimeState
    bundle_result: Any
    reporting_fiber_id: int
    reporting_geometry: Dict[str, Any]
    electrode_points: Sequence[Any]
    metadata: Dict[str, Any]

    @property
    def per_fiber_cable_results(self) -> Dict[int, Dict[str, Any]]:
        return getattr(self.bundle_result, "per_fiber_cable_results", {})

    @property
    def vc_result(self) -> Optional[Dict[str, Any]]:
        return getattr(self.bundle_result, "vc_result", None)

    @property
    def knp_result(self) -> Optional[Dict[str, Any]]:
        return getattr(self.bundle_result, "knp_result", None)

    @property
    def bundle_history(self) -> Dict[str, Any]:
        return getattr(self.bundle_result, "bundle_history", {})


def _resolve_reporting_fiber_id(
    architecture_spec: NerveArchitectureSpec,
    reporting_fiber_id: Optional[int],
) -> int:
    if architecture_spec.fiber_count <= 0:
        raise ValueError("NerveArchitectureSpec must contain at least one fiber.")

    valid_ids = {int(f.fiber_id) for f in architecture_spec.fibers}
    if reporting_fiber_id is None:
        return int(architecture_spec.fibers[0].fiber_id)

    fid = int(reporting_fiber_id)
    if fid not in valid_ids:
        raise ValueError(
            f"reporting_fiber_id={fid} is not present in the architecture spec. "
            f"Valid IDs: {sorted(valid_ids)}"
        )
    return fid


def run_architecture_simulation(
    architecture_spec: NerveArchitectureSpec,
    params: SimulationParameters = DEFAULT_PARAMS,
    reporting_fiber_id: Optional[int] = None,
    stimulated_fiber_ids: Optional[Sequence[int]] = None,
    enable_vc: Optional[bool] = None,
    enable_knp: Optional[bool] = None,
    enable_ecs_feedback: Optional[bool] = None,
    knp_species: str = "K",
    bundle_state: Optional[BundleRuntimeState] = None,
) -> ArchitectureSimulationResult:
    architecture_spec.validate()
    fid_report = _resolve_reporting_fiber_id(architecture_spec, reporting_fiber_id)

    bundle_geometry = build_bundle_from_architecture(architecture_spec, params=params)

    if bundle_state is None:
        bundle_state = initialize_bundle_state(bundle_geometry=bundle_geometry, params=params)

    electrode_points = build_electrode_points_from_architecture(
        architecture_spec,
        ring_min_points=8,
        include_explicit_electrodes=True,
        include_cuffs=True,
        cuff_mode="ring",
        cuff_ring_contact_count=8,
    )

    bundle_result = run_multirate_bundle_simulation(
        bundle_geometry=bundle_geometry,
        bundle_state=bundle_state,
        params=params,
        electrode_points=electrode_points,
        stimulated_fiber_ids=stimulated_fiber_ids,
        enable_vc=enable_vc,
        enable_knp=enable_knp,
        enable_ecs_feedback=enable_ecs_feedback,
        knp_species=knp_species,
    )

    reporting_geometry = bundle_geometry.get_fiber_geometry(fid_report)
    result_metadata = getattr(bundle_result, "metadata", {}) or {}

    metadata = {
        "bundle_id": bundle_geometry.metadata.get("bundle_id", architecture_spec.bundle_id),
        "layout_name": getattr(bundle_geometry, "layout_name", architecture_spec.layout_name),
        "fiber_count": int(getattr(bundle_geometry, "total_fiber_count", architecture_spec.fiber_count)),
        "reporting_fiber_id": int(fid_report),
        "stimulated_fiber_ids": None if stimulated_fiber_ids is None else [int(fid) for fid in stimulated_fiber_ids],
        "electrode_count": int(len(electrode_points)),
        "enable_vc": bool(result_metadata.get("enable_vc", False)) if result_metadata else bool(enable_vc),
        "enable_knp": bool(result_metadata.get("enable_knp", False)) if result_metadata else bool(enable_knp),
        "feedback_enabled": bool(result_metadata.get("feedback_enabled", False)) if result_metadata else bool(enable_ecs_feedback),
        "knp_species": str(knp_species),
    }

    return ArchitectureSimulationResult(
        architecture_spec=architecture_spec,
        bundle_geometry=bundle_geometry,
        bundle_state=bundle_state,
        bundle_result=bundle_result,
        reporting_fiber_id=fid_report,
        reporting_geometry=reporting_geometry,
        electrode_points=electrode_points,
        metadata=metadata,
    )


def summarize_architecture_run(result: ArchitectureSimulationResult) -> Dict[str, Any]:
    peak_vm_by_fiber: Dict[int, float] = {}
    for fid, cable in result.per_fiber_cable_results.items():
        vm = cable.get("V_m_mV", None)
        if vm is None:
            continue
        peak_vm_by_fiber[int(fid)] = float(np.max(np.asarray(vm, dtype=float)))

    summary: Dict[str, Any] = {
        "bundle_id": result.metadata.get("bundle_id"),
        "fiber_count": int(result.metadata.get("fiber_count", 0)),
        "reporting_fiber_id": int(result.reporting_fiber_id),
        "electrode_count": int(result.metadata.get("electrode_count", 0)),
        "peak_vm_by_fiber_mV": peak_vm_by_fiber,
    }

    if result.knp_result is not None:
        phi_e = result.knp_result.get("phi_e_mV", None)
        if phi_e is not None:
            phi_arr = np.asarray(phi_e, dtype=float)
            summary["knp_phi_min_mV"] = float(np.min(phi_arr))
            summary["knp_phi_max_mV"] = float(np.max(phi_arr))

        source_debug = result.knp_result.get("source_debug", None)
        if isinstance(source_debug, dict):
            summary["knp_max_abs_source_mM_per_ms"] = float(
                source_debug.get("max_abs_source_mM_per_ms", 0.0)
            )

    if result.vc_result is not None:
        peak_vc_by_electrode = {}
        for key, value in result.vc_result.items():
            if key == "t_ms":
                continue
            arr = np.asarray(value, dtype=float)
            peak_vc_by_electrode[str(key)] = float(np.max(np.abs(arr)))
        summary["peak_vc_by_electrode_mV"] = peak_vc_by_electrode

    return summary