"""
plotting.py

Minimal plotting helpers for custom-architecture NeuroSolver runs.

These routines are intentionally lightweight and operate directly on the current
bundle/cable/KNP/VC result dictionaries returned by the existing scheduler.
"""

from __future__ import annotations

from pathlib import Path
from typing import Dict, Optional, Tuple

import matplotlib.pyplot as plt
import numpy as np


FigureAxes = Tuple[plt.Figure, plt.Axes]


def _finalize_axes_equal(ax) -> None:
    ax.set_aspect("equal")
    ax.relim()
    ax.autoscale_view()


def save_figure(fig, filepath: str, dpi: int = 200, close: bool = False) -> None:
    """
    Save a figure with tight bounding and optional close.
    """
    path = Path(filepath)
    path.parent.mkdir(parents=True, exist_ok=True)
    fig.savefig(path, dpi=dpi, bbox_inches="tight")
    if close:
        plt.close(fig)


def plot_architecture_cross_section(
    bundle_geometry,
    show_fascicles: bool = True,
    architecture_spec=None,
    show_electrodes: bool = True,
) -> FigureAxes:
    """
    Plot the transverse y-z layout of the explicit fiber placements.

    Parameters
    ----------
    bundle_geometry:
        BundleGeometry object.
    show_fascicles:
        Draw declared fascicle boundaries if available.
    architecture_spec:
        Optional NerveArchitectureSpec. If not provided, attempts to use
        bundle_geometry.metadata["architecture_spec"].
    show_electrodes:
        Overlay point/ring/multicontact electrode positions in the transverse
        plane when architecture metadata is available.
    """
    fig, ax = plt.subplots()

    if architecture_spec is None:
        architecture_spec = bundle_geometry.metadata.get("architecture_spec", None)

    if show_fascicles and architecture_spec is not None:
        for fascicle in getattr(architecture_spec, "fascicles", []):
            boundary = plt.Circle(
                (float(fascicle.center_y_um), float(fascicle.center_z_um)),
                float(fascicle.radius_um),
                fill=False,
                linestyle="--",
                linewidth=1.2,
                alpha=0.8,
            )
            ax.add_patch(boundary)
            if fascicle.label:
                ax.text(
                    float(fascicle.center_y_um),
                    float(fascicle.center_z_um) + float(fascicle.radius_um),
                    fascicle.label,
                    ha="center",
                    va="bottom",
                    fontsize=8,
                )

    for placement in bundle_geometry.placements:
        geometry = bundle_geometry.get_fiber_geometry(placement.fiber_id)
        outer_diameter = np.asarray(geometry["outer_diameter_um"], dtype=float)
        radius_um = 0.5 * float(np.max(outer_diameter))

        circle = plt.Circle(
            (float(placement.center_y_um), float(placement.center_z_um)),
            radius_um,
            fill=False,
            linewidth=1.2,
        )
        ax.add_patch(circle)
        ax.text(
            float(placement.center_y_um),
            float(placement.center_z_um),
            str(int(placement.fiber_id)),
            ha="center",
            va="center",
            fontsize=8,
        )

    if show_electrodes and architecture_spec is not None:
        for electrode in getattr(architecture_spec, "electrodes", []):
            ey = float(electrode.y_um)
            ez = float(electrode.z_um)
            ax.plot([ey], [ez], marker="x", linestyle="None")
            if electrode.label:
                ax.text(ey, ez, electrode.label, ha="left", va="bottom", fontsize=8)

            if electrode.kind == "ring" and electrode.radius_um is not None:
                ring = plt.Circle(
                    (ey, ez),
                    float(electrode.radius_um),
                    fill=False,
                    linestyle=":",
                    linewidth=1.0,
                    alpha=0.8,
                )
                ax.add_patch(ring)

    ax.set_xlabel("y (um)")
    ax.set_ylabel("z (um)")
    ax.set_title(f"Bundle cross-section: {bundle_geometry.metadata.get('bundle_id', 'bundle')}")
    _finalize_axes_equal(ax)
    return fig, ax


def plot_reporting_fiber_propagation(
    cable_result: Dict[str, np.ndarray],
    geometry: Optional[Dict[str, np.ndarray]] = None,
    field_key: str = "V_m_mV",
    title: Optional[str] = None,
) -> FigureAxes:
    """
    Plot a cable field as an x-t heatmap for one reporting fiber.

    field_key examples
    ------------------
    - "V_m_mV"
    - "V_membrane_effective_mV"  (if present in result)
    """
    if field_key not in cable_result:
        raise KeyError(f"{field_key!r} not found in cable_result.")

    t_ms = np.asarray(cable_result["t_ms"], dtype=float)
    field = np.asarray(cable_result[field_key], dtype=float)
    x_um = np.asarray(
        cable_result["x_um"] if geometry is None else geometry["x_um"],
        dtype=float,
    )

    fig, ax = plt.subplots()
    im = ax.imshow(
        field.T,
        aspect="auto",
        origin="lower",
        extent=[float(t_ms[0]), float(t_ms[-1]), float(x_um[0]), float(x_um[-1])],
    )
    ax.set_xlabel("t (ms)")
    ax.set_ylabel("x (um)")
    ax.set_title(title or f"Reporting fiber: {field_key}")
    fig.colorbar(im, ax=ax, label=field_key)
    return fig, ax


def plot_knp_phi_heatmap(knp_result: Dict[str, object]) -> FigureAxes:
    """
    Plot shared KNP extracellular potential as an x-t heatmap.
    """
    t_ms = np.asarray(knp_result["t_ms"], dtype=float)
    x_um = np.asarray(knp_result["x_um"], dtype=float)
    phi_e_mV = np.asarray(knp_result["phi_e_mV"], dtype=float)

    fig, ax = plt.subplots()
    im = ax.imshow(
        phi_e_mV.T,
        aspect="auto",
        origin="lower",
        extent=[float(t_ms[0]), float(t_ms[-1]), float(x_um[0]), float(x_um[-1])],
    )
    ax.set_xlabel("t (ms)")
    ax.set_ylabel("x (um)")
    ax.set_title("Shared KNP extracellular potential")
    fig.colorbar(im, ax=ax, label="phi_e (mV)")
    return fig, ax


def plot_knp_species_heatmap(
    knp_result: Dict[str, object],
    species_name: str = "K",
    delta_from_baseline: Optional[float] = None,
) -> FigureAxes:
    """
    Plot one KNP species concentration history as an x-t heatmap.

    Parameters
    ----------
    delta_from_baseline:
        If provided, subtract this scalar baseline concentration before plotting.
    """
    species_histories = knp_result.get("species_mM", None)
    if not isinstance(species_histories, dict) or species_name not in species_histories:
        available = [] if not isinstance(species_histories, dict) else sorted(species_histories.keys())
        raise KeyError(
            f"Species {species_name!r} not found in knp_result['species_mM']. Available: {available}"
        )

    t_ms = np.asarray(knp_result["t_ms"], dtype=float)
    x_um = np.asarray(knp_result["x_um"], dtype=float)
    species_mM = np.asarray(species_histories[species_name], dtype=float)

    label = f"[{species_name}] (mM)"
    title = f"Shared KNP species: {species_name}"

    if delta_from_baseline is not None:
        species_mM = species_mM - float(delta_from_baseline)
        label = f"Δ[{species_name}] (mM)"
        title = f"Shared KNP species delta: {species_name}"

    fig, ax = plt.subplots()
    im = ax.imshow(
        species_mM.T,
        aspect="auto",
        origin="lower",
        extent=[float(t_ms[0]), float(t_ms[-1]), float(x_um[0]), float(x_um[-1])],
    )
    ax.set_xlabel("t (ms)")
    ax.set_ylabel("x (um)")
    ax.set_title(title)
    fig.colorbar(im, ax=ax, label=label)
    return fig, ax


def plot_vc_traces(vc_result: Dict[str, np.ndarray]) -> FigureAxes:
    """
    Plot VC waveforms. The current VC result format is:
        {"t_ms": ..., electrode_name_1: trace, electrode_name_2: trace, ...}
    """
    t_ms = np.asarray(vc_result["t_ms"], dtype=float)

    fig, ax = plt.subplots()
    for key, value in vc_result.items():
        if key == "t_ms":
            continue
        ax.plot(t_ms, np.asarray(value, dtype=float), label=str(key))

    ax.set_xlabel("t (ms)")
    ax.set_ylabel("phi_e (mV)")
    ax.set_title("Virtual electrode traces")
    ax.legend()
    return fig, ax


def plot_fiber_peak_vm_by_id(
    per_fiber_cable_results: Dict[int, Dict[str, np.ndarray]],
    field_key: str = "V_m_mV",
) -> FigureAxes:
    """
    Bar plot of peak field magnitude by fiber ID.
    """
    fiber_ids = sorted(int(fid) for fid in per_fiber_cable_results.keys())
    peaks = []
    for fid in fiber_ids:
        if field_key not in per_fiber_cable_results[fid]:
            raise KeyError(f"{field_key!r} missing from cable result for fiber {fid}.")
        peaks.append(
            float(np.max(np.asarray(per_fiber_cable_results[fid][field_key], dtype=float)))
        )

    fig, ax = plt.subplots()
    ax.bar(fiber_ids, peaks)
    ax.set_xlabel("Fiber ID")
    ax.set_ylabel(f"Peak {field_key}")
    ax.set_title(f"Peak {field_key} by fiber")
    return fig, ax


def plot_architecture_result_overview(result) -> Dict[str, FigureAxes]:
    """
    Convenience plotting wrapper for ArchitectureSimulationResult.

    Returns
    -------
    dict
        Keys may include:
        - "architecture"
        - "propagation"
        - "vc"
        - "knp_phi"
        - "fiber_peaks"
    """
    figures: Dict[str, FigureAxes] = {}

    figures["architecture"] = plot_architecture_cross_section(
        result.bundle_geometry,
        architecture_spec=result.architecture_spec,
    )

    reporting_cable = result.per_fiber_cable_results[result.reporting_fiber_id]
    figures["propagation"] = plot_reporting_fiber_propagation(
        reporting_cable,
        geometry=result.reporting_geometry,
        field_key="V_m_mV",
        title=f"Reporting fiber {result.reporting_fiber_id}: V_m_mV",
    )

    figures["fiber_peaks"] = plot_fiber_peak_vm_by_id(
        result.per_fiber_cable_results,
        field_key="V_m_mV",
    )

    if result.vc_result is not None:
        figures["vc"] = plot_vc_traces(result.vc_result)

    if result.knp_result is not None:
        figures["knp_phi"] = plot_knp_phi_heatmap(result.knp_result)

    return figures